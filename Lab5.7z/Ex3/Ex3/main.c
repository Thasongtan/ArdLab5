#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#define F_CPU 16000000UL
#define BAUD 9600
#include <util/setbaud.h>
#define LED PB5
void uart_putchar(char c, FILE *stream) {
	if (c == '\n') uart_putchar('\r', stream);
	loop_until_bit_is_set(UCSR0A, UDRE0);
	UDR0 = c;
}
char uart_getchar(FILE *stream) {
	loop_until_bit_is_set(UCSR0A, RXC0);
	return UDR0;
}
FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);
void fPrintfInit(void) {
	UBRR0H = UBRRH_VALUE;
	UBRR0L = UBRRL_VALUE;
	UCSR0A &= ~(_BV(U2X0));
	UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);
	UCSR0B = _BV(RXEN0) | _BV(TXEN0);
	stdout = &uart_output;
	stdin = &uart_input;
}
//-----------------------------------------------------------
void fInitTimer() {
	TCCR0A |= (1<<WGM01); // Set Timer0 to CTC mode
	OCR0A = 0xF9;
	TIMSK0 |= (1<<OCIE0A);
	TCCR0B |= (1<<CS01)|(1<<CS00);
	sei();
}
volatile unsigned int cnt,max_cnt=100;
int main(void) {
	unsigned int adc_rd;
	fPrintfInit();
	DDRB |= _BV(LED); // Set pin for LED
	PORTB &= ~_BV(LED); // Turn off LED
	fInitTimer(); // Set Timer0
	ADMUX |= (1<<REFS0); // Vref=AVcc=5V,16-bit output
	ADMUX |= (1<<MUX0); // Select ADC1 (ch1)
	DIDR0 |= (1<<PINC1); // PC1 disabled
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // CLKadc=CLKsys/128
	ADCSRA |= (1<<ADEN); // ADC Enabled
	while(1) {
		ADCSRA |= (1<<ADSC); // Start conversion
		while (ADCSRA&(1<<ADSC)); // Wait until conversion done
		//- Read 10-bit ADC output
		adc_rd = ADCL; // Lower 8 bits
		adc_rd += ADCH<<8; // Higher 2 bits
		double tossaniyom = 0.0073421439;
		float kohmahasombat = tossaniyom*adc_rd;
		max_cnt = adc_rd;
		//------------------------
		printf("ADC = %1.3f\n",kohmahasombat); // Show result
	}
	return 0;
}
// Timer0'Output Compare ISR
ISR (TIMER0_COMPA_vect) {
	cnt++;
	if (cnt>=max_cnt) {
		PORTB ^= _BV(LED);
		cnt=0;
	}
}